package com.aiconnect.mobile

import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import org.json.JSONArray
import java.util.concurrent.TimeUnit

private val Ink = Color(0xFF101827)
private val Panel = Color(0xFF1B2638)
private val Accent = Color(0xFF6EE7D8)
private val Muted = Color(0xFF9AA8BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AIConnectScreen() }
    }
}

data class Answer(val provider: String, val text: String, val error: Boolean = false)

@Composable
fun AIConnectScreen() {
    var prompt by remember { mutableStateOf("") }
    var apiUrl by remember { mutableStateOf("https://ai-connect-backend.onrender.com") }
    var synthesize by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Connect your backend to begin.") }
    var answers by remember { mutableStateOf(listOf<Answer>()) }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    var ttsReady by remember { mutableStateOf(false) }
    val tts = remember {
        TextToSpeech(context) { result ->
            ttsReady = result == TextToSpeech.SUCCESS
        }
    }
    DisposableEffect(tts) {
        onDispose {
            tts.stop()
            tts.shutdown()
        }
    }
    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) prompt = spoken
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Ink, surface = Panel,
        onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Ink).padding(18.dp)
        ) {
            Text("AI CONNECT", color = Accent, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Text("One question. Multiple AI minds.", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(18.dp))

            Text("BACKEND ADDRESS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            InputBox(apiUrl, { apiUrl = it }, "https://ai-connect-backend.onrender.com")
            Spacer(Modifier.height(14.dp))

            Text("YOUR QUESTION", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier.fillMaxWidth().heightIn(min = 110.dp)
                    .background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)
            ) {
                if (prompt.isBlank()) Text("Ask a question for your AI team…", color = Muted)
                BasicTextField(
                    value = prompt, onValueChange = { prompt = it },
                    modifier = Modifier.fillMaxWidth(), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 16.sp)
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                OutlinedButton(
                    onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your question")
                        }
                        try {
                            speechLauncher.launch(intent)
                        } catch (_: Exception) {
                            status = "Voice input is not available. Please install or enable a speech recognition service."
                        }
                    }
                ) { Text("🎙 SPEAK QUESTION", color = Accent) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row {
                    Checkbox(checked = synthesize, onCheckedChange = { synthesize = it }, colors = CheckboxDefaults.colors(checkedColor = Accent))
                    Text("Master AI summary", color = Color.White, modifier = Modifier.padding(top = 12.dp))
                }
                Button(
                    enabled = !busy && prompt.isNotBlank(),
                    onClick = {
                        busy = true
                        answers = emptyList()
                        status = "AI agents are working…"
                        scope.launch {
                            try {
                                val result = withContext(Dispatchers.IO) { callBackend(apiUrl.trimEnd('/'), prompt, synthesize) }
                                answers = result.first
                                status = result.second
                            } catch (e: Exception) {
                                status = "Connection failed: ${e.message ?: "unknown error"}"
                            } finally { busy = false }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink)
                ) { Text(if (busy) "Working…" else "ASK AI TEAM", fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(8.dp))
            Text(status, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(answers) { answer ->
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(14.dp)) {
                        Text(answer.provider.uppercase(), color = if (answer.error) Color(0xFFFF9B9B) else Accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(Modifier.height(7.dp))
                        Text(answer.text, color = Color.White, fontSize = 14.sp, lineHeight = 20.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = {
                                if (ttsReady) {
                                    tts.language = Locale.getDefault()
                                    tts.speak(answer.text, TextToSpeech.QUEUE_FLUSH, null, "ai-connect-answer")
                                }
                            }) { Text("🔊 READ ALOUD", color = Accent) }
                            TextButton(onClick = { tts.stop() }) { Text("■ STOP", color = Muted) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InputBox(value: String, onValueChange: (String) -> Unit, hint: String) {
    Box(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(12.dp)) {
        if (value.isBlank()) Text(hint, color = Muted)
        BasicTextField(value, onValueChange, modifier = Modifier.fillMaxWidth(),
            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp))
    }
}

private fun callBackend(base: String, prompt: String, synthesize: Boolean): Pair<List<Answer>, String> {
    val client = OkHttpClient.Builder().callTimeout(180, TimeUnit.SECONDS).build()
    val json = JSONObject().put("prompt", prompt).put("synthesize", synthesize)
    val body = json.toString().toRequestBody("application/json".toMediaType())
    val request = Request.Builder().url("$base/api/compare").post(body).build()
    client.newCall(request).execute().use { response ->
        val raw = response.body?.string().orEmpty()
        if (!response.isSuccessful) error("HTTP ${response.code}: $raw")
        val root = JSONObject(raw)
        val list = mutableListOf<Answer>()
        val arr: JSONArray = root.optJSONArray("results") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            list.add(Answer(item.optString("provider", "AI"), item.optString("text", ""), item.optBoolean("error", false)))
        }
        if (root.has("synthesis")) {
            val s = root.optJSONObject("synthesis")
            if (s != null) list.add(0, Answer("Master AI — combined answer", s.optString("text", "No synthesis returned."), s.optBoolean("error", false)))
        }
        return Pair(list, root.optString("message", "Finished."))
    }
}
