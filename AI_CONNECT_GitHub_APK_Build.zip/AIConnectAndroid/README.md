# AI CONNECT — Android starter project

An Android (Kotlin + Jetpack Compose) client for a multi-model AI collaboration backend.

## What this MVP does
- Lets a user enter a question.
- Sends it to a backend that queries configured AI providers in parallel.
- Displays each model's response.
- Optionally asks a configured "Master AI" to synthesize the responses.

## Important
This is a source project, not a prebuilt APK. The backend is required. API keys belong on the backend, never inside the Android app.

## Requirements
- Android Studio (current stable)
- JDK 17
- Android SDK 35
- Python 3.10+

## 1. Start the backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```
Add the API keys you have to `backend/.env`, then:
```bash
uvicorn app:app --host 0.0.0.0 --port 8000
```

Supported providers in this starter:
- OpenAI
- Google Gemini
- Anthropic Claude
- xAI Grok
- DeepSeek

Only providers with a configured key are called. Availability, model names, API access and pricing depend on each provider account. The app does not log in to or control the consumer apps installed from Google Play.

## 2. Connect the Android app
Open this folder in Android Studio.

For the Android emulator, the default API address is `http://10.0.2.2:8000/`.
For a physical phone, change the API address in the app to your computer's LAN IP, e.g. `http://192.168.1.20:8000/`, and ensure both devices are on the same Wi-Fi network.

For local development, the app permits HTTP traffic. Before production release, use HTTPS and remove cleartext traffic permission.

## 3. Build APK
In Android Studio:
- Wait for Gradle sync.
- Select Build > Build Bundle(s) / APK(s) > Build APK(s).
- Android Studio will show the generated APK location.

## API endpoint
`POST /api/compare`
```json
{
  "prompt": "Compare three small business ideas for India",
  "synthesize": true
}
```

## Safety and privacy
- Do not put provider API keys in the Android app.
- The prompt is sent to your backend and then to each provider you enabled.
- Review each provider's privacy and retention terms before sending sensitive information.
- Add authentication, rate limits, billing controls and HTTPS before making this public.
