import os
import asyncio
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

load_dotenv()
app = FastAPI(title="AI CONNECT API", version="1.0")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_credentials=False,
    allow_methods=["*"], allow_headers=["*"]
)

class CompareRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=12000)
    synthesize: bool = True

async def post_json(url, headers, payload):
    async with httpx.AsyncClient(timeout=100) as client:
        r = await client.post(url, headers=headers, json=payload)
        r.raise_for_status()
        return r.json()

async def openai_compatible(provider, key, model, prompt, base_url):
    data = await post_json(
        f"{base_url}/chat/completions",
        {"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        {"model": model, "messages": [
            {"role": "system", "content": "You are one member of a collaborative AI team. Answer clearly, state uncertainty, and do not invent facts."},
            {"role": "user", "content": prompt}
        ], "temperature": 0.3}
    )
    return data["choices"][0]["message"]["content"]

async def call_openai(prompt):
    return await openai_compatible("openai", os.getenv("OPENAI_API_KEY"), os.getenv("OPENAI_MODEL", "gpt-4o-mini"), prompt, "https://api.openai.com/v1")

async def call_xai(prompt):
    return await openai_compatible("xai", os.getenv("XAI_API_KEY"), os.getenv("XAI_MODEL", "grok-2-latest"), prompt, "https://api.x.ai/v1")

async def call_deepseek(prompt):
    return await openai_compatible("deepseek", os.getenv("DEEPSEEK_API_KEY"), os.getenv("DEEPSEEK_MODEL", "deepseek-chat"), prompt, "https://api.deepseek.com")

async def call_gemini(prompt):
    key = os.getenv("GEMINI_API_KEY")
    model = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
    data = await post_json(
        f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}",
        {"Content-Type": "application/json"},
        {"contents": [{"parts": [{"text": "You are one member of a collaborative AI team. Be accurate and state uncertainty.\n\n" + prompt}]}]}
    )
    return "".join(p.get("text", "") for p in data["candidates"][0]["content"]["parts"])

async def call_anthropic(prompt):
    key = os.getenv("ANTHROPIC_API_KEY")
    model = os.getenv("ANTHROPIC_MODEL", "claude-3-5-haiku-latest")
    data = await post_json(
        "https://api.anthropic.com/v1/messages",
        {"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
        {"model": model, "max_tokens": 1200, "messages": [{"role": "user", "content": prompt}]}
    )
    return "".join(x.get("text", "") for x in data.get("content", []) if x.get("type") == "text")

PROVIDERS = [
    ("OpenAI", "OPENAI_API_KEY", call_openai),
    ("Gemini", "GEMINI_API_KEY", call_gemini),
    ("Claude", "ANTHROPIC_API_KEY", call_anthropic),
    ("Grok", "XAI_API_KEY", call_xai),
    ("DeepSeek", "DEEPSEEK_API_KEY", call_deepseek),
]

async def safe_call(name, fn, prompt):
    try:
        return {"provider": name, "text": await fn(prompt), "error": False}
    except Exception as exc:
        return {"provider": name, "text": f"Provider request failed: {str(exc)[:350]}", "error": True}

@app.get("/health")
async def health():
    return {"ok": True, "service": "AI CONNECT API"}

@app.post("/api/compare")
async def compare(req: CompareRequest):
    active = [(name, fn) for name, env, fn in PROVIDERS if os.getenv(env)]
    if not active:
        raise HTTPException(400, "No provider API keys configured. Add at least one key to backend/.env.")
    results = await asyncio.gather(*(safe_call(name, fn, req.prompt) for name, fn in active))
    successful = [x for x in results if not x["error"]]
    synthesis = None

    master = os.getenv("MASTER_PROVIDER", "openai").lower()
    if req.synthesize and successful:
        summary_prompt = (
            "You are the Master AI coordinating a panel of AI assistants. Synthesize their responses into "
            "one useful answer. Identify agreement, disagreement, uncertainty and missing evidence. Do not "
            "pretend claims were independently verified. User question:\n" + req.prompt +
            "\n\nPanel responses:\n" +
            "\n\n".join(f"[{x['provider']}]\n{x['text']}" for x in successful)
        )
        master_map = {"openai": call_openai, "gemini": call_gemini, "claude": call_anthropic, "grok": call_xai, "deepseek": call_deepseek}
        master_fn = master_map.get(master)
        master_key = {"openai":"OPENAI_API_KEY","gemini":"GEMINI_API_KEY","claude":"ANTHROPIC_API_KEY","grok":"XAI_API_KEY","deepseek":"DEEPSEEK_API_KEY"}.get(master)
        if master_fn and master_key and os.getenv(master_key):
            item = await safe_call("Master AI synthesis", master_fn, summary_prompt)
            synthesis = {"text": item["text"], "error": item["error"]}

    return {
        "message": f"Received {len(results)} provider response(s); {len(successful)} succeeded.",
        "results": results,
        "synthesis": synthesis
    }
